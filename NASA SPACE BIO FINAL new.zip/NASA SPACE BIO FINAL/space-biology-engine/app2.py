from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
import pandas as pd
import requests
from io import StringIO
import re
import os
from datetime import datetime
import time
from bs4 import BeautifulSoup
import xml.etree.ElementTree as ET
import threading
import ast

app = Flask(__name__)
CORS(app)

class SpaceBiologyData:
    def __init__(self):
        self.csv_url = 'https://raw.githubusercontent.com/jgalazka/SB_publications/main/SB_publication_PMC.csv'
        self.df = None
        self.papers = []
        self.topic_summaries = {}
        # Default: do fast CSV extraction only. Enable scraping separately via the refresh endpoint.
        self.scrape_authors = False
        
    def load_data(self):
        """Load data from GitHub CSV"""
        try:
            print("Loading data from GitHub...")
            raw_url = 'https://raw.githubusercontent.com/jgalazka/SB_publications/main/SB_publication_PMC.csv'
            response = requests.get(raw_url, timeout=30)
            response.raise_for_status()
            
            csv_data = StringIO(response.text)
            self.df = pd.read_csv(csv_data)
            print(f"Loaded {len(self.df)} records from CSV")
            
            self.process_papers()
            self.generate_topic_summaries()
            
            # Optionally enhance with author scraping
            if self.scrape_authors:
                self.enhance_with_authors()
                
            return True
            
        except Exception as e:
            print(f"Error loading data: {e}")
            return False
    
    def process_papers(self):
        """Process papers with the available data structure"""
        self.papers = []
        
        for idx, row in self.df.iterrows():
            try:
                title = str(row.get('Title', '')).strip()
                if not title:
                    continue
                
                # Extract PMC ID from link
                pmc_url = str(row.get('Link', ''))
                pmc_id = self.extract_pmc_id(pmc_url)
                
                year = self.extract_year_from_title(title)
                journal = self.infer_journal_from_pmc(pmc_url)
                abstract = 'Abstract available at the publication link'
                tags = self.generate_tags(title, '')
                publisher = self.get_publisher('', journal)
                detailed_summary = self.generate_detailed_summary(row, '')
                publication_links = self.create_publication_links(row)
                primary_link = self.get_primary_link(publication_links)
                
                # Fast author extraction from CSV (no scraping)
                authors = self.extract_authors_from_row(row) or ('Loading author information...' if self.scrape_authors else 'Unknown Authors')
                
                paper = {
                    'id': idx + 1,
                    'title': title,
                    'authors': authors,
                    'journal': journal,
                    'publisher': publisher,
                    'date': year,
                    'abstract': abstract,
                    'detailed_summary': detailed_summary,
                    'tags': tags,
                    'pmcId': pmc_id,
                    'doi': '',  # Not available in current dataset
                    'url': pmc_url,
                    'publication_links': publication_links,
                    'primary_link': primary_link,
                    'has_abstract': False,  # We don't have abstracts in this dataset
                    'primary_topic': self.identify_primary_topic(title, ''),
                    'access_status': 'likely_open_access'  # PMC is generally open access
                }
                
                self.papers.append(paper)
                
            except Exception as e:
                print(f"Error processing row {idx}: {e}")
                continue
        
        print(f"Successfully processed {len(self.papers)} papers")
    
    def enhance_with_authors(self):
        """Enhance papers with author information from PMC"""
        print("Enhancing papers with author information...")
        successful_scrapes = 0
        
        for i, paper in enumerate(self.papers):
            if paper.get('url') and 'pmc' in paper['url']:
                try:
                    authors = self.scrape_authors_from_pmc(paper['url'])
                    if authors and authors != 'Authors not available':
                        paper['authors'] = authors
                        successful_scrapes += 1
                    else:
                        paper['authors'] = 'Author information available at the publication link'
                    
                    # Add delay to be respectful to PMC servers
                    time.sleep(0.3)
                    
                except Exception as e:
                    print(f"Error scraping authors for paper {paper['id']}: {e}")
                    paper['authors'] = 'Author information available at the publication link'
            
            if i % 10 == 0:
                print(f"Processed {i+1}/{len(self.papers)} papers")
        
        print(f"Author enhancement complete. Successfully scraped {successful_scrapes}/{len(self.papers)} papers")
    
    def scrape_authors_from_pmc(self, pmc_url):
        """Scrape author information from PMC article pages"""
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            response = requests.get(pmc_url, headers=headers, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Try multiple selectors for author information
            authors = []
            
            # Selector 1: Common PMC author format
            author_elements = soup.select('.contrib-group .name')
            if not author_elements:
                # Selector 2: Alternative PMC format
                author_elements = soup.select('.authors-list .name')
            if not author_elements:
                # Selector 3: Another common format
                author_elements = soup.select('.auths a')
            if not author_elements:
                # Selector 4: Try by text content
                author_elements = soup.find_all(['span', 'div'], string=re.compile(r'[A-Z][a-z]+ [A-Z]'))
            
            for element in author_elements[:10]:  # Limit to first 10 authors
                author_text = element.get_text(strip=True)
                # Basic validation to ensure it looks like a name
                if (author_text and 
                    len(author_text) > 3 and 
                    any(c.isalpha() for c in author_text) and
                    author_text not in authors):
                    authors.append(author_text)
            
            if authors:
                return ', '.join(authors[:8])  # Limit to 8 authors for display
            
            return 'Authors not available'
            
        except Exception as e:
            print(f"Error scraping authors from {pmc_url}: {e}")
            return 'Authors not available'
    
    def extract_pmc_id(self, url):
        """Extract PMC ID from URL"""
        if 'articles/' in url:
            return url.split('articles/')[-1].strip('/')
        return ''
    
    def infer_journal_from_pmc(self, pmc_url):
        """Attempt to infer journal from PMC URL patterns"""
        # Common journal patterns in PMC URLs
        journal_patterns = {
            'nature': 'Nature',
            'scirep': 'Scientific Reports',
            'plos': 'PLOS',
            'cell': 'Cell',
            'science': 'Science',
            'jbc': 'Journal of Biological Chemistry',
            'pnas': 'Proceedings of the National Academy of Sciences',
            'faseb': 'FASEB Journal',
            'bmc': 'BMC',
            'frontiers': 'Frontiers'
        }
        
        url_lower = pmc_url.lower()
        for pattern, journal in journal_patterns.items():
            if pattern in url_lower:
                return journal
        
        return 'Various Journals'
    
    def extract_year_from_title(self, title):
        """Extract year from title if possible, otherwise use current year"""
        import re
        from datetime import datetime
        
        # Look for 4-digit years in title (common in citation formats)
        year_match = re.search(r'\((\d{4})\)', title)
        if year_match:
            return year_match.group(1)
        
        # Look for years in other formats
        year_match = re.search(r'\b(20\d{2})\b', title)
        if year_match:
            return year_match.group(1)
        
        # Default to current year
        return str(datetime.now().year)
    
    def create_publication_links(self, row):
        """Create publication links from available data"""
        links = {}
        pmc_url = str(row.get('Link', ''))
        
        if pmc_url and pmc_url.startswith('http'):
            links['pmc'] = pmc_url
            
            # Try to extract DOI from PMC URL or infer it
            doi = self.extract_doi_from_pmc(pmc_url)
            if doi:
                links['doi'] = f"https://doi.org/{doi}"
        
        return links
    
    def extract_doi_from_pmc(self, pmc_url):
        """Attempt to extract or infer DOI from PMC URL"""
        try:
            # Some PMC URLs contain DOI information
            if 'doi.org' in pmc_url:
                return pmc_url.split('doi.org/')[-1]
            
            # For now, return None since we don't have reliable DOI extraction
            return None
        except:
            return None
    
    def get_primary_link(self, links):
        """Get the best available link to display as primary"""
        if 'pmc' in links:
            return {
                'url': links['pmc'],
                'type': 'PMC',
                'display_name': 'View on PubMed Central'
            }
        return None

    # Keep all your existing methods for topic summaries, tagging, etc.
    def generate_topic_summaries(self):
        """Generate comprehensive summaries for each research topic"""
        self.topic_summaries = {
            'microgravity': {
                'name': 'Microgravity Effects',
                'summary': """Microgravity research represents one of the most fundamental areas of space biology, examining how biological systems function in the absence of Earth's gravity. This research investigates cellular processes, gene expression patterns, and physiological adaptations that occur when gravity is removed from the equation.""",
                'key_findings': [
                    'Altered gene expression profiles across multiple biological systems and cell types',
                    'Significant changes in cell morphology, division patterns, and communication',
                    'Modified immune response characteristics with increased infection susceptibility',
                    'Altered bone density regulation and muscle mass maintenance mechanisms'
                ]
            },
            'radiation': {
                'name': 'Space Radiation Biology',
                'summary': """Space radiation biology investigates the complex effects of cosmic radiation on living organisms, representing a major challenge for human space exploration beyond Earth's protective magnetosphere.""",
                'key_findings': [
                    'Complex DNA damage patterns requiring specialized cellular repair mechanisms',
                    'Significantly increased oxidative stress levels and chronic inflammation markers',
                    'Tissue-specific vulnerability patterns with nervous system showing high sensitivity'
                ]
            },
            # ... (keep your existing topic summaries, shortened for brevity)
            'plants': {
                'name': 'Space Plant Biology',
                'summary': """Space plant biology represents a critical research area focused on understanding how plants grow, develop, and reproduce in the unique environment of space.""",
                'key_findings': [
                    'Dramatically altered root system architecture with modified branching patterns',
                    'Significant changes in gene expression related to stress responses and development'
                ]
            }
        }
    
    def generate_detailed_summary(self, row, abstract):
        """Generate a comprehensive summary for each paper"""
        title = str(row.get('Title', ''))
        primary_topic = self.identify_primary_topic(title, abstract)
        
        # Get the comprehensive topic summary
        if primary_topic in self.topic_summaries:
            topic_info = self.topic_summaries[primary_topic]
            base_summary = topic_info['summary']
        else:
            base_summary = self.topic_summaries['microgravity']['summary']
        
        enhanced_summary = f"""RESEARCH OVERVIEW: {title}

COMPREHENSIVE TOPIC CONTEXT:
{base_summary}

SPECIFIC RESEARCH FOCUS:
This investigation examines {self.get_research_focus(title, abstract)} through sophisticated research methodologies. The research provides novel insights into {self.get_biological_system(title)} under space conditions.

MAJOR CONTRIBUTIONS AND IMPLICATIONS:
Findings from this research significantly advance our understanding of {self.get_biological_system(title)} and have profound implications for {self.get_implications(title, primary_topic)}.

CONCLUSION:
This research represents a substantial advancement in space biology knowledge, providing critical insights that support both scientific understanding and practical applications for space exploration."""
        return enhanced_summary
    
    def identify_primary_topic(self, title, abstract):
        """Identify the primary research topic"""
        content = f"{title} {abstract}".lower()
        
        topic_keywords = {
            'microgravity': ['microgravity', 'weightlessness', 'spaceflight', 'μg', 'simulated microgravity'],
            'radiation': ['radiation', 'cosmic', 'gamma', 'proton', 'ionizing', 'irradiation'],
            'plants': ['plant', 'arabidopsis', 'root', 'photosynthesis', 'seedling', 'brassica'],
            'microbes': ['bacteria', 'microbial', 'yeast', 'fungal', 'virulence', 'microbiome'],
            'human': ['human', 'astronaut', 'health', 'physiology', 'crew', 'clinical'],
            'drosophila': ['drosophila', 'fruit fly', 'melanogaster'],
            'rodent': ['mouse', 'mice', 'rat', 'rodent', 'murine'],
            'cell_biology': ['cell', 'cellular', 'in vitro', 'tissue', 'cytoskeleton'],
            'immunology': ['immune', 'immunology', 'lymphocyte', 'cytokine'],
            'neuroscience': ['neural', 'brain', 'behavior', 'cognitive', 'vestibular']
        }
        
        for topic, keywords in topic_keywords.items():
            if any(keyword in content for keyword in keywords):
                return topic
        
        return 'microgravity'
    
    def get_research_focus(self, title, abstract):
        """Extract research focus from title and abstract"""
        content = f"{title} {abstract}".lower()
        
        focus_map = {
            'effect': "the effects of space environment on biological systems",
            'mechanism': "the underlying molecular and cellular mechanisms of space adaptation",
            'development': "developmental processes and growth patterns in space conditions",
            'response': "biological responses to spaceflight stressors",
            'adaptation': "adaptive mechanisms to space environment",
            'change': "changes in biological function in microgravity",
            'impact': "the impact of space conditions on physiological function"
        }
        
        for key, focus in focus_map.items():
            if key in content:
                return focus
        
        return "fundamental biological processes in space environments"
    
    def get_biological_system(self, title):
        """Identify the biological system studied"""
        title_lower = title.lower()
        
        systems = {
            'cell': 'cellular processes and organization',
            'gene': 'gene expression patterns and regulation',
            'protein': 'protein synthesis and function',
            'dna': 'DNA integrity and repair mechanisms',
            'immune': 'immune system function and regulation',
            'neural': 'neural development and function',
            'muscle': 'muscle physiology and adaptation',
            'bone': 'bone density regulation and remodeling',
            'cardio': 'cardiovascular system function',
            'metabolic': 'metabolic pathways and regulation'
        }
        
        for key, system in systems.items():
            if key in title_lower:
                return system
        
        return 'biological systems and adaptation mechanisms'
    
    def get_implications(self, title, topic):
        """Get research implications"""
        implications = {
            'microgravity': 'long-duration space mission planning and astronaut health',
            'radiation': 'radiation protection strategies and safety protocols',
            'plants': 'space agriculture and life support systems',
            'microbes': 'spacecraft hygiene and infection control',
            'human': 'countermeasure development and health monitoring',
            'drosophila': 'fundamental biological mechanism understanding',
            'rodent': 'mammalian adaptation insights and therapeutic development',
            'cell_biology': 'basic cellular mechanism elucidation',
            'immunology': 'immune health maintenance strategies',
            'neuroscience': 'neurological adaptation understanding'
        }
        
        return implications.get(topic, 'space exploration advancement and scientific knowledge expansion')
    
    def generate_tags(self, title, abstract):
        """Generate tags based on paper content"""
        tags = []
        title_text = (str(title) if title else '').lower()
        content = f"{title_text}"
        
        space_biology_terms = {
            'microgravity': 'Microgravity',
            'spaceflight': 'Spaceflight',
            'radiation': 'Radiation',
            'plant': 'Plant Biology',
            'arabidopsis': 'Arabidopsis',
            'drosophila': 'Drosophila',
            'mouse': 'Mouse Models',
            'human': 'Human Physiology',
            'bacteria': 'Bacteria',
            'immune': 'Immune System',
            'neural': 'Neural',
            'cell': 'Cell Biology',
            'gene': 'Gene Expression',
            'protein': 'Protein',
            'dna': 'DNA',
            'bone': 'Bone Biology',
            'muscle': 'Muscle Physiology',
            'cancer': 'Cancer Biology',
            'mitochondria': 'Mitochondria',
            'transcriptom': 'Transcriptomics',
            'proteom': 'Proteomics',
            'metabolom': 'Metabolomics'
        }
        
        for term, tag in space_biology_terms.items():
            if term in content:
                tags.append(tag)
        
        if not tags:
            tags = ['Space Biology']
        
        return list(set(tags))[:8]  # Remove duplicates and limit
    
    def get_publisher(self, publisher, journal):
        """Get or infer publisher information"""
        if publisher and str(publisher).strip():
            return str(publisher).strip()
        
        journal_lower = journal.lower()
        if 'nature' in journal_lower:
            return 'Springer Nature'
        elif 'science' in journal_lower:
            return 'American Association for the Advancement of Science'
        elif 'cell' in journal_lower:
            return 'Cell Press'
        elif 'plos' in journal_lower:
            return 'Public Library of Science'
        else:
            return 'Various Publishers'
    
    def parse_authors_string(self, val):
        """Quick parser for common CSV author formats"""
        if val is None:
            return None
        s = str(val).strip()
        if not s or s.lower() in ('nan', 'none', 'unknown', '[]'):
            return None
        s = re.sub(r'\s+', ' ', s).strip(' ,;')
        # Try JSON/list
        if s.startswith('[') and s.endswith(']'):
            try:
                arr = ast.literal_eval(s)
                if isinstance(arr, (list, tuple)):
                    return ', '.join([str(x).strip() for x in arr if str(x).strip()])
            except Exception:
                pass
        # common separators
        if ';' in s or '|' in s:
            parts = re.split(r'[;|]', s)
            return ', '.join(p.strip(' .') for p in parts if p.strip())
        # Last, F. style
        matches = re.findall(r"[A-Za-z\-\']+,\s*[A-Za-z\.\-]+", s)
        if matches:
            return ', '.join(matches)
        # fallback: return trimmed string
        return s

    def extract_authors_from_row(self, row):
        """Try common CSV columns to get authors quickly (no network)."""
        if row is None:
            return None
        possible = ['Authors','Author','AU','AU_LIST','AuthorList','authors','authors_list','Author(s)','Creator','Contributors']
        for k in possible:
            try:
                val = row.get(k)
            except Exception:
                val = None
            parsed = self.parse_authors_string(val)
            if parsed:
                return parsed
        # Heuristic scan: look for "Last, F." patterns anywhere in the row
        pattern = re.compile(r"[A-Za-z\-\']+,\s*[A-Za-z\.\-]+")
        for _, cell in row.items():
            if pd.isna(cell):
                continue
            cell_str = str(cell)
            m = pattern.findall(cell_str)
            if m:
                return ', '.join(m[:8])
        return None

# Initialize data handler
data_handler = SpaceBiologyData()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/papers')
def get_papers():
    """Get all papers with abstracts and summaries"""
    if not data_handler.papers:
        success = data_handler.load_data()
        if not success:
            return jsonify(get_sample_data())
    
    return jsonify(data_handler.papers)

@app.route('/api/papers/<int:paper_id>')
def get_paper(paper_id):
    """Get specific paper details"""
    if not data_handler.papers:
        data_handler.load_data()
    
    paper = next((p for p in data_handler.papers if p['id'] == paper_id), None)
    
    if paper:
        return jsonify(paper)
    else:
        return jsonify({'error': 'Paper not found'}), 404

@app.route('/api/topics')
def get_topics():
    """Get all research topics with their summaries"""
    if not data_handler.topic_summaries:
        data_handler.generate_topic_summaries()
    
    return jsonify(data_handler.topic_summaries)

@app.route('/api/statistics')
def get_statistics():
    """Get application statistics"""
    if not data_handler.papers:
        data_handler.load_data()
    
    papers = data_handler.papers
    
    total_papers = len(papers)
    papers_with_authors = len([p for p in papers if p.get('authors') and 'Loading' not in p['authors'] and 'available at' not in p['authors']])
    
    # Count papers by primary topic
    topic_counts = {}
    for paper in papers:
        topic = paper.get('primary_topic', 'unknown')
        topic_counts[topic] = topic_counts.get(topic, 0) + 1
    
    # Find most common topic
    most_common_topic = max(topic_counts.items(), key=lambda x: x[1]) if topic_counts else ('unknown', 0)
    
    return jsonify({
        'total_papers': total_papers,
        'papers_with_authors': papers_with_authors,
        'most_common_topic': most_common_topic[0],
        'topic_counts': topic_counts
    })

@app.route('/api/search')
def search_papers():
    """Search papers by query"""
    query = request.args.get('q', '').lower()
    topic = request.args.get('topic', '').lower()
    
    if not data_handler.papers:
        data_handler.load_data()
    
    if not query and not topic:
        return jsonify(data_handler.papers[:50])
    
    filtered_papers = []
    for paper in data_handler.papers:
        matches_query = not query or (
            query in paper['title'].lower() or
            query in paper.get('authors', '').lower() or
            query in paper['journal'].lower() or
            any(query in tag.lower() for tag in paper['tags'])
        )
        
        matches_topic = not topic or paper.get('primary_topic') == topic
        
        if matches_query and matches_topic:
            filtered_papers.append(paper)
    
    return jsonify(filtered_papers)

@app.route('/api/refresh-authors')
def refresh_authors():
    """Trigger background author scraping (returns immediately)."""
    if not data_handler.papers:
        data_handler.load_data()
    # run scraping in background thread so endpoint is fast
    thread = threading.Thread(target=data_handler.enhance_with_authors, daemon=True)
    thread.start()
    return jsonify({'status': 'started', 'message': 'Author scraping running in background'}), 202

def get_sample_data():
    """Fallback sample data"""
    return [
        {
            "id": 1,
            "title": "Effects of Microgravity on Arabidopsis thaliana Root Growth and Development",
            "authors": "Smith, J., Johnson, A., Williams, R., Brown, K., Davis, M., Wilson, E.",
            "journal": "Nature Communications",
            "publisher": "Springer Nature",
            "date": "2023",
            "abstract": "Abstract available at the publication link",
            "detailed_summary": "Detailed summary about microgravity effects on plant systems...",
            "tags": ["Microgravity", "Plant Biology", "Arabidopsis"],
            "url": "https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1234567",
            "publication_links": {
                "pmc": "https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1234567"
            },
            "primary_link": {
                "url": "https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1234567",
                "type": "PMC",
                "display_name": "View on PubMed Central"
            },
            "has_abstract": False,
            "primary_topic": "plants",
            "access_status": "likely_open_access"
        }
    ]

if __name__ == '__main__':
    print("Starting Space Biology Knowledge Engine...")
    data_handler.load_data()
    app.run(debug=True, port=5000)