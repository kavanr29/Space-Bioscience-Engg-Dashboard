// Global variables
let allPapers = [];
let filteredPapers = [];
let currentPage = 1;
const papersPerPage = 9;

// Graph globals
let graphNetwork = null;
let graphNodes = null;
let graphEdges = null;
// Speech synthesis control
let currentUtterance = null;
let _suppressSpeechError = false;
let speechSentences = [];
let currentSpeechIndex = 0;
let isSpeechPlaying = false;

// Try to get a usable voice; returns a Promise that resolves to a SpeechSynthesisVoice or null
function getPreferredVoice() {
    return new Promise((resolve) => {
        const attempt = () => {
            const voices = window.speechSynthesis.getVoices();
            if (voices && voices.length > 0) {
                // prefer en-US or en voices
                let v = voices.find(x => /en[-_]?us/i.test(x.lang));
                if (!v) v = voices.find(x => /^en/i.test(x.lang));
                if (!v) v = voices[0];
                resolve(v);
                return true;
            }
            return false;
        };

        if (attempt()) return;
        // wait for voiceschanged
        const handler = () => {
            if (attempt()) {
                window.speechSynthesis.removeEventListener('voiceschanged', handler);
            }
        };
        window.speechSynthesis.addEventListener('voiceschanged', handler);
        // fallback timeout
        setTimeout(() => {
            const voices = window.speechSynthesis.getVoices();
            resolve((voices && voices[0]) || null);
        }, 1500);
    });
}

// API endpoints
const API_BASE = '/api';
const ENDPOINTS = {
    PAPERS: `${API_BASE}/papers`,
    STATISTICS: `${API_BASE}/statistics`,
    SEARCH: `${API_BASE}/search`,
    TOPICS: `${API_BASE}/topics`
};

// Create stars in the header
function createStars() {
    const starsContainer = document.getElementById('stars');
    const starCount = 150;
    
    for (let i = 0; i < starCount; i++) {
        const star = document.createElement('div');
        star.classList.add('star');
        const x = Math.random() * 100;
        const y = Math.random() * 100;
        const size = Math.random() * 3;
        const delay = Math.random() * 5;
        
        star.style.left = `${x}%`;
        star.style.top = `${y}%`;
        star.style.width = `${size}px`;
        star.style.height = `${size}px`;
        star.style.animationDelay = `${delay}s`;
        
        starsContainer.appendChild(star);
    }
}

// Load data from backend API
async function loadData() {
    try {
        showLoadingState();
        
        const [papersResponse, statsResponse] = await Promise.all([
            fetch(ENDPOINTS.PAPERS),
            fetch(ENDPOINTS.STATISTICS)
        ]);
        
        if (!papersResponse.ok || !statsResponse.ok) {
            throw new Error('Failed to load data from server');
        }
        
        allPapers = await papersResponse.json();
        const statistics = await statsResponse.json();
        
        updateStatistics(statistics);
        initializeApp();
        
    } catch (error) {
        console.error('Error loading data:', error);
        showErrorState('Failed to load data. Please refresh the page or try again later.');
    }
}

// Show loading state
function showLoadingState() {
    document.getElementById('papersContainer').innerHTML = `
        <div class="loading pulse">
            <i class="fas fa-spinner fa-spin"></i> Loading comprehensive space biology data with detailed summaries...
        </div>
    `;
    
    document.getElementById('totalPapers').textContent = '...';
    document.getElementById('papersWithAbstracts').textContent = '...';
    document.getElementById('topJournal').textContent = '...';
    document.getElementById('recentPapers').textContent = '...';
}

// Show error state
function showErrorState(message) {
    document.getElementById('papersContainer').innerHTML = `
        <div class="no-results">
            <i class="fas fa-exclamation-triangle"></i>
            <h3>Unable to Load Data</h3>
            <p>${message}</p>
            <button class="filter-btn" onclick="loadData()" style="margin-top: 20px;">
                <i class="fas fa-redo"></i> Try Again
            </button>
        </div>
    `;
    
    document.getElementById('dataInfo').textContent = 'Using fallback data';
}

// Update statistics display
function updateStatistics(statistics) {
    document.getElementById('totalPapers').textContent = statistics.total_papers;
    document.getElementById('papersWithAbstracts').textContent = statistics.papers_with_abstracts;
    document.getElementById('topJournal').textContent = statistics.top_journal;
    document.getElementById('recentPapers').textContent = statistics.recent_papers;
    
    const abstractPercentage = Math.round((statistics.papers_with_abstracts / statistics.total_papers) * 100);
    document.getElementById('dataInfo').textContent = 
        `Loaded ${statistics.total_papers} publications • ${abstractPercentage}% with comprehensive summaries`;
}

// Initialize the application with loaded data
function initializeApp() {
    setupFilters();
    filteredPapers = [...allPapers];
    applySorting();
    displayPapers();
    setupPagination();
    setupEventListeners();
    updateResultsCount();
    // Load knowledge graph after initial data is ready
    loadGraph();
}

// Load and render knowledge graph
async function loadGraph() {
    try {
        const resp = await fetch('/api/graph');
        if (!resp.ok) return;
        const data = await resp.json();

        // Use vis-network if available
        if (window.vis && data.nodes && data.edges) {
            const nodes = new vis.DataSet(data.nodes.map(n => ({ id: n.id, label: n.label, group: n.group }))); 
            const edges = new vis.DataSet(data.edges.map(e => ({ from: e.from, to: e.to })));

            const container = document.getElementById('network');
            const options = {
                nodes: { shape: 'dot', scaling: { min: 6, max: 36 }, font: { size: 14 } },
                edges: { arrows: { to: false }, smooth: { type: 'force' } },
                groups: {
                    topic: { color: { background: 'var(--accent)' }, shape: 'diamond' },
                    journal: { color: { background: 'var(--accent-2)' } },
                    paper: { color: { background: '#ffffff10' } }
                },
                physics: { stabilization: true, barnesHut: { gravitationalConstant: -3000 } },
                interaction: { hover: true, tooltipDelay: 100 }
            };

            // assign to globals so other controls can use them
            graphNodes = nodes;
            graphEdges = edges;
            graphNetwork = new vis.Network(container, { nodes: graphNodes, edges: graphEdges }, options);
            graphNetwork.on('selectNode', function(params) {
                // If a paper node is selected, try to open its details
                const nodeId = params.nodes && params.nodes[0];
                if (!nodeId) return;
                if (nodeId.startsWith('paper::')) {
                    const pid = parseInt(nodeId.split('::')[1]);
                    const paper = allPapers.find(p => p.id === pid);
                    if (paper) showPaperDetails(paper);
                }
            });
        }
    } catch (err) {
        console.warn('Failed to load knowledge graph', err);
    }
}

// Set up filter options dynamically
function setupFilters() {
    // Extract unique years
    const years = [...new Set(allPapers.map(paper => paper.date))]
        .filter(year => year !== 'Unknown')
        .sort((a, b) => b - a);
    
    const yearFiltersContainer = document.getElementById('yearFilters');
    yearFiltersContainer.innerHTML = '';
    
    years.forEach(year => {
        const label = document.createElement('label');
        label.className = 'filter-option';
        label.innerHTML = `<input type="checkbox" name="year" value="${year}" checked> ${year}`;
        yearFiltersContainer.appendChild(label);
    });
    
    // Extract unique research areas from tags
    const allTags = new Set();
    allPapers.forEach(paper => {
        paper.tags.forEach(tag => allTags.add(tag));
    });
    
    const areaFiltersContainer = document.getElementById('areaFilters');
    areaFiltersContainer.innerHTML = '';
    
    Array.from(allTags).sort().forEach(area => {
        const label = document.createElement('label');
        label.className = 'filter-option';
        label.innerHTML = `<input type="checkbox" name="area" value="${area.toLowerCase()}" checked> ${area}`;
        areaFiltersContainer.appendChild(label);
    });
    
    // Extract unique journals
    const journalCounts = {};
    allPapers.forEach(paper => {
        const journal = paper.journal;
        if (journal !== 'Unknown Journal') {
            journalCounts[journal] = (journalCounts[journal] || 0) + 1;
        }
    });
    
    const topJournals = Object.entries(journalCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 15)
        .map(entry => entry[0]);
        
    const journalFiltersContainer = document.getElementById('journalFilters');
    journalFiltersContainer.innerHTML = '';
    
    topJournals.forEach(journal => {
        const label = document.createElement('label');
        label.className = 'filter-option';
        label.innerHTML = `<input type="checkbox" name="journal" value="${journal.toLowerCase()}" checked> ${journal}`;
        journalFiltersContainer.appendChild(label);
    });
}

// Apply filters based on user selection
function applyFilters() {
    const selectedYears = Array.from(document.querySelectorAll('input[name="year"]:checked'))
        .map(checkbox => checkbox.value);
        
    const selectedAreas = Array.from(document.querySelectorAll('input[name="area"]:checked'))
        .map(checkbox => checkbox.value);
        
    const selectedJournals = Array.from(document.querySelectorAll('input[name="journal"]:checked'))
        .map(checkbox => checkbox.value);
    
    filteredPapers = allPapers.filter(paper => {
        const yearMatch = selectedYears.length === 0 || selectedYears.includes(paper.date);
        const areaMatch = selectedAreas.length === 0 || 
            paper.tags.some(tag => selectedAreas.includes(tag.toLowerCase()));
        const journalMatch = selectedJournals.length === 0 || 
            selectedJournals.includes(paper.journal.toLowerCase());
        
        return yearMatch && areaMatch && journalMatch;
    });
    
    applySorting();
    currentPage = 1;
    displayPapers();
    setupPagination();
    updateResultsCount();
}

// Apply sorting
function applySorting() {
    const sortBy = document.getElementById('sortSelect').value;
    
    switch(sortBy) {
        case 'recent':
            filteredPapers.sort((a, b) => {
                if (a.date === 'Unknown') return 1;
                if (b.date === 'Unknown') return -1;
                return parseInt(b.date) - parseInt(a.date);
            });
            break;
        case 'title':
            filteredPapers.sort((a, b) => a.title.localeCompare(b.title));
            break;
        case 'journal':
            filteredPapers.sort((a, b) => a.journal.localeCompare(b.journal));
            break;
    }
}

// Update results count display
function updateResultsCount() {
    const count = filteredPapers.length;
    const resultsElement = document.getElementById('resultsCount');
    
    if (count === 0) {
        resultsElement.textContent = 'No publications found';
    } else if (count === 1) {
        resultsElement.textContent = '1 publication found';
    } else {
        resultsElement.textContent = `${count} publications found`;
    }
}

// Display papers based on current page
function displayPapers() {
    const container = document.getElementById('papersContainer');
    
    if (filteredPapers.length === 0) {
        container.innerHTML = `
            <div class="no-results">
                <i class="fas fa-search"></i>
                <h3>No Publications Found</h3>
                <p>Try adjusting your filters or search terms</p>
            </div>
        `;
        return;
    }
    
    const startIndex = (currentPage - 1) * papersPerPage;
    const endIndex = Math.min(startIndex + papersPerPage, filteredPapers.length);
    const papersToShow = filteredPapers.slice(startIndex, endIndex);
    
    container.innerHTML = '';
    
    papersToShow.forEach(paper => {
        const paperElement = document.createElement('div');
        paperElement.classList.add('paper-card');
        
        const truncatedAbstract = paper.abstract.length > 200 
            ? paper.abstract.substring(0, 200) + '...' 
            : paper.abstract;
        
        // Only render authors if they are provided and not a generic placeholder
        const authorsText = (paper.authors && paper.authors !== 'Unknown Authors') ? paper.authors : '';
        const authorsHTML = authorsText ? `<div class="paper-authors">${authorsText}</div>` : '';
        const journalHTML = (paper.journal && paper.journal !== 'Unknown Journal') ? `<div class="paper-journal">${paper.journal}</div>` : '';
        const dateHTML = (paper.date && paper.date !== 'Unknown') ? `<div class="paper-date">Published: ${paper.date}</div>` : '';

        paperElement.innerHTML = `
            <h3 class="paper-title">${paper.title}</h3>
            ${authorsHTML}
            ${journalHTML}
            ${dateHTML}
            <p class="paper-abstract">${truncatedAbstract}</p>
            <div class="paper-tags">
                ${paper.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
            </div>
        `;
        
        paperElement.addEventListener('click', () => showPaperDetails(paper));
        container.appendChild(paperElement);
    });
}

// Show paper details in modal with comprehensive summary
function showPaperDetails(paper) {
    const modal = document.getElementById('paperModal');
    const modalTitle = document.getElementById('modalTitle');
    const modalAuthors = document.getElementById('modalAuthors');
    const journalName = document.getElementById('journalName');
    const modalDate = document.getElementById('modalDate');
    const modalPublisher = document.getElementById('modalPublisher');
    const modalAbstract = document.getElementById('modalAbstract');
    const modalTags = document.getElementById('modalTags');
    const paperLinksSection = document.getElementById('paperLinksSection');
    const paperLinks = document.getElementById('paperLinks');
    const openPaperBtn = document.getElementById('openPaperBtn');
    
    modalTitle.textContent = paper.title;
    // Only show authors when provided and not a generic placeholder
    if (paper.authors && paper.authors !== 'Unknown Authors') {
        modalAuthors.style.display = 'block';
        modalAuthors.textContent = paper.authors;
    } else {
        modalAuthors.style.display = 'none';
        modalAuthors.textContent = '';
    }
    // Show journal only when meaningful
    if (paper.journal && paper.journal !== 'Unknown Journal') {
        journalName.textContent = paper.journal;
        journalName.style.display = 'flex';
    } else {
        journalName.textContent = '';
        journalName.style.display = 'none';
    }

    if (paper.date && paper.date !== 'Unknown') {
        modalDate.textContent = `Published: ${paper.date}`;
        modalDate.style.display = 'flex';
    } else {
        modalDate.textContent = '';
        modalDate.style.display = 'none';
    }

    if (paper.publisher && paper.publisher !== 'Various Publishers' && paper.publisher.trim() !== '') {
        modalPublisher.textContent = `Publisher: ${paper.publisher}`;
        modalPublisher.style.display = 'flex';
    } else {
        modalPublisher.textContent = '';
        modalPublisher.style.display = 'none';
    }
    
    // Display comprehensive summary
    const abstractContent = modalAbstract.querySelector('.abstract-content');
    if (paper.detailed_summary) {
        abstractContent.innerHTML = paper.detailed_summary.split('\n').map(line => 
            line.trim() ? `<p>${line}</p>` : ''
        ).join('');
    } else {
        abstractContent.innerHTML = `<p>${paper.abstract}</p>`;
    }
    
    modalTags.innerHTML = '';
    paper.tags.forEach(tag => {
        const tagElement = document.createElement('span');
        tagElement.className = 'tag';
        tagElement.textContent = tag;
        modalTags.appendChild(tagElement);
    });
    
    paperLinks.innerHTML = '';
    if (paper.url) {
        paperLinksSection.style.display = 'block';
        const linkElement = document.createElement('a');
        linkElement.href = paper.url;
        linkElement.target = '_blank';
        linkElement.className = 'paper-link';
        linkElement.innerHTML = `
            <i class="fas fa-external-link-alt"></i>
            <div>
                <strong>Access Full Paper</strong>
                <div class="link-url">${paper.doi || paper.pmcId || paper.url}</div>
            </div>
        `;
        paperLinks.appendChild(linkElement);
    } else {
        paperLinksSection.style.display = 'none';
    }
    
    if (paper.url) {
        openPaperBtn.style.display = 'flex';
        openPaperBtn.onclick = () => window.open(paper.url, '_blank');
    } else {
        openPaperBtn.style.display = 'none';
    }
    
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';

    // Set up Listen Summary button to use the current paper content
    const listenId = 'listenSummaryBtn';
    let listenBtn = document.getElementById(listenId);
    const summaryText = paper.detailed_summary || paper.abstract || paper.title;
    if (!listenBtn) {
        listenBtn = document.createElement('button');
        listenBtn.id = listenId;
        listenBtn.className = 'filter-btn';
        listenBtn.style.marginLeft = '8px';
        listenBtn.textContent = 'Listen Summary';
        const actions = document.querySelector('.modal-actions');
        if (actions) actions.insertBefore(listenBtn, actions.firstChild);
    }

    // replace previous handler with sentence-by-sentence playback and highlighting
    listenBtn.onclick = () => {
        if (!('speechSynthesis' in window)) {
            alert('Speech synthesis not supported in this browser.');
            return;
        }

        // stop any existing speech
        try { _suppressSpeechError = true; window.speechSynthesis.cancel(); } catch(e){}
        speechSentences = splitIntoSentences(summaryText);
        currentSpeechIndex = 0;
        isSpeechPlaying = true;

        // prepare visual indicator
        let indicator = document.getElementById('speechIndicator');
        if (!indicator) {
            indicator = document.createElement('span');
            indicator.id = 'speechIndicator';
            indicator.style.marginLeft = '10px';
            indicator.style.fontSize = '0.9rem';
            indicator.style.color = 'var(--accent)';
            const actions = document.querySelector('.modal-actions');
            if (actions) actions.appendChild(indicator);
        }
        indicator.textContent = 'Playing...';

        // highlight container: ensure abstract content is split into spans
        const abstractContent = document.querySelector('#modalAbstract .abstract-content');
        populateSentenceSpans(abstractContent, speechSentences);

        // play the sentences sequentially
        function playNextSentence() {
            if (!isSpeechPlaying || currentSpeechIndex >= speechSentences.length) {
                // finished
                indicator.textContent = '';
                isSpeechPlaying = false;
                currentSpeechIndex = 0;
                highlightSentence(abstractContent, -1);
                return;
            }

            const sentence = speechSentences[currentSpeechIndex];
            const u = new SpeechSynthesisUtterance(sentence);
            u.rate = 1.0; u.pitch = 1.0;
            currentUtterance = u;
            highlightSentence(abstractContent, currentSpeechIndex);
            u.onend = () => {
                currentSpeechIndex += 1;
                playNextSentence();
            };
            u.onerror = (e) => {
                if (_suppressSpeechError) { _suppressSpeechError = false; return; }
                console.warn('TTS sentence error', e);
                // try to continue
                currentSpeechIndex += 1;
                playNextSentence();
            };
            window.speechSynthesis.speak(u);
        }

        playNextSentence();
    };

    // Add pause/resume/stop buttons if not present
    let pauseBtn = document.getElementById('pauseSpeechBtn');
    if (!pauseBtn) {
        pauseBtn = document.createElement('button');
        pauseBtn.id = 'pauseSpeechBtn';
        pauseBtn.className = 'action-btn secondary';
        pauseBtn.style.marginLeft = '8px';
        pauseBtn.textContent = 'Pause';
        pauseBtn.onclick = () => {
            if (window.speechSynthesis && window.speechSynthesis.speaking) window.speechSynthesis.pause();
        };
        const actions = document.querySelector('.modal-actions');
        if (actions) actions.appendChild(pauseBtn);
    }

    let resumeBtn = document.getElementById('resumeSpeechBtn');
    if (!resumeBtn) {
        resumeBtn = document.createElement('button');
        resumeBtn.id = 'resumeSpeechBtn';
        resumeBtn.className = 'action-btn';
        resumeBtn.style.marginLeft = '8px';
        resumeBtn.textContent = 'Resume';
        resumeBtn.onclick = () => {
            if (window.speechSynthesis && window.speechSynthesis.paused) window.speechSynthesis.resume();
        };
        const actions = document.querySelector('.modal-actions');
        if (actions) actions.appendChild(resumeBtn);
    }

    let stopBtn = document.getElementById('stopSpeechBtn');
    if (!stopBtn) {
        stopBtn = document.createElement('button');
        stopBtn.id = 'stopSpeechBtn';
        stopBtn.className = 'action-btn secondary';
        stopBtn.style.marginLeft = '8px';
        stopBtn.textContent = 'Stop';
        stopBtn.onclick = () => {
            if (window.speechSynthesis) {
                try { _suppressSpeechError = true; window.speechSynthesis.cancel(); } catch(e){}
                currentUtterance = null;
                const indicator = document.getElementById('speechIndicator');
                if (indicator) indicator.textContent = '';
            }
        };
        const actions = document.querySelector('.modal-actions');
        if (actions) actions.appendChild(stopBtn);
    }
}

// Set up pagination
function setupPagination() {
    const paginationContainer = document.getElementById('pagination');
    paginationContainer.innerHTML = '';
    
    const totalPages = Math.ceil(filteredPapers.length / papersPerPage);
    
    if (totalPages <= 1) return;
    
    if (currentPage > 1) {
        const prevButton = document.createElement('button');
        prevButton.className = 'page-btn';
        prevButton.innerHTML = '<i class="fas fa-chevron-left"></i>';
        prevButton.addEventListener('click', () => {
            currentPage--;
            displayPapers();
            setupPagination();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
        paginationContainer.appendChild(prevButton);
    }
    
    const startPage = Math.max(1, currentPage - 2);
    const endPage = Math.min(totalPages, currentPage + 2);
    
    for (let i = startPage; i <= endPage; i++) {
        const pageButton = document.createElement('button');
        pageButton.className = `page-btn ${i === currentPage ? 'active' : ''}`;
        pageButton.textContent = i;
        pageButton.addEventListener('click', () => {
            currentPage = i;
            displayPapers();
            setupPagination();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
        paginationContainer.appendChild(pageButton);
    }
    
    if (currentPage < totalPages) {
        const nextButton = document.createElement('button');
        nextButton.className = 'page-btn';
        nextButton.innerHTML = '<i class="fas fa-chevron-right"></i>';
        nextButton.addEventListener('click', () => {
            currentPage++;
            displayPapers();
            setupPagination();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
        paginationContainer.appendChild(nextButton);
    }
}

// Helper: split text into sentences (naive but practical)
function splitIntoSentences(text) {
    if (!text) return [];
    // simple sentence splitter using punctuation with lookahead
    const parts = text
        .replace(/\r\n/g, ' ')
        .replace(/\n/g, ' ')
        .split(/(?<=[\.\?\!])\s+(?=[A-Z0-9\-"'\(])/);
    return parts.map(p => p.trim()).filter(Boolean);
}

// Render the abstract content as span-wrapped sentences for highlighting
function populateSentenceSpans(container, sentences) {
    if (!container) return;
    container.innerHTML = '';
    sentences.forEach((s, idx) => {
        const span = document.createElement('span');
        span.className = 'tts-sentence';
        span.dataset.sidx = idx;
        span.textContent = s + (s.endsWith('.') ? ' ' : ' ');
        container.appendChild(span);
    });
}

// Highlight a sentence by index, or remove highlight if idx < 0
function highlightSentence(container, idx) {
    if (!container) return;
    container.querySelectorAll('.tts-sentence').forEach(span => {
        const sidx = parseInt(span.dataset.sidx, 10);
        if (sidx === idx) {
            span.style.background = 'linear-gradient(90deg, rgba(46,230,214,0.08), rgba(255,159,107,0.03))';
            span.style.padding = '4px 6px';
            span.style.borderRadius = '6px';
        } else {
            span.style.background = 'transparent';
            span.style.padding = '';
            span.style.borderRadius = '';
        }
    });
}

// Set up event listeners
function setupEventListeners() {
    document.getElementById('searchBtn').addEventListener('click', performSearch);
    document.getElementById('searchInput').addEventListener('keyup', (e) => {
        if (e.key === 'Enter') performSearch();
    });
    
    document.querySelectorAll('.filter-btn[data-filter]').forEach(button => {
        button.addEventListener('click', function() {
            document.querySelectorAll('.filter-btn[data-filter]').forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            const filter = this.getAttribute('data-filter');
            
            switch(filter) {
                case 'recent':
                    filteredPapers = allPapers.filter(paper => {
                        const paperYear = parseInt(paper.date);
                        const currentYear = new Date().getFullYear();
                        return !isNaN(paperYear) && paperYear >= currentYear - 2;
                    });
                    break;
                case 'with-abstract':
                    filteredPapers = allPapers.filter(paper => paper.has_abstract);
                    break;
                case 'microgravity':
                    filteredPapers = allPapers.filter(paper => 
                        paper.tags.includes('Microgravity') || 
                        paper.title.toLowerCase().includes('microgravity') ||
                        paper.abstract.toLowerCase().includes('microgravity')
                    );
                    break;
                default:
                    filteredPapers = [...allPapers];
            }
            
            applySorting();
            currentPage = 1;
            displayPapers();
            setupPagination();
            updateResultsCount();
        });
    });
    
    document.getElementById('applyFilters').addEventListener('click', applyFilters);
    document.getElementById('resetFilters').addEventListener('click', resetFilters);
    document.getElementById('sortSelect').addEventListener('change', () => {
        applySorting();
        currentPage = 1;
        displayPapers();
        setupPagination();
    });
    
    document.getElementById('closeModal').addEventListener('click', closeModal);
    document.getElementById('closePaperBtn').addEventListener('click', closeModal);
    
    window.addEventListener('click', (event) => {
        const modal = document.getElementById('paperModal');
        if (event.target === modal) {
            closeModal();
        }
    });
    
    window.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            closeModal();
        }
    });
}

// Close modal
function closeModal() {
    const modal = document.getElementById('paperModal');
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Reset all filters
function resetFilters() {
    document.querySelectorAll('.filter-option input').forEach(checkbox => {
        checkbox.checked = true;
    });
    
    document.querySelectorAll('.filter-btn[data-filter]').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector('.filter-btn[data-filter="all"]').classList.add('active');
    
    document.getElementById('searchInput').value = '';
    document.getElementById('sortSelect').value = 'recent';
    
    filteredPapers = [...allPapers];
    applySorting();
    currentPage = 1;
    displayPapers();
    setupPagination();
    updateResultsCount();
}

// Perform search
async function performSearch() {
    const searchTerm = document.getElementById('searchInput').value.trim();
    
    if (searchTerm) {
        try {
            const response = await fetch(`${ENDPOINTS.SEARCH}?q=${encodeURIComponent(searchTerm)}`);
            if (response.ok) {
                filteredPapers = await response.json();
            } else {
                filteredPapers = allPapers.filter(paper => {
                    const q = searchTerm.toLowerCase();
                    const inTitle = paper.title && paper.title.toLowerCase().includes(q);
                    const inAuthors = paper.authors && paper.authors.toLowerCase().includes(q);
                    const inAbstract = paper.abstract && paper.abstract.toLowerCase().includes(q);
                    const inJournal = paper.journal && paper.journal.toLowerCase().includes(q);
                    const inTags = paper.tags && paper.tags.some(tag => tag.toLowerCase().includes(q));
                    return inTitle || inAuthors || inAbstract || inJournal || inTags;
                });
            }
        } catch (error) {
            filteredPapers = allPapers.filter(paper => {
                const q = searchTerm.toLowerCase();
                const inTitle = paper.title && paper.title.toLowerCase().includes(q);
                const inAuthors = paper.authors && paper.authors.toLowerCase().includes(q);
                const inAbstract = paper.abstract && paper.abstract.toLowerCase().includes(q);
                const inJournal = paper.journal && paper.journal.toLowerCase().includes(q);
                const inTags = paper.tags && paper.tags.some(tag => tag.toLowerCase().includes(q));
                return inTitle || inAuthors || inAbstract || inJournal || inTags;
            });
        }
    } else {
        filteredPapers = [...allPapers];
    }
    
    applySorting();
    currentPage = 1;
    displayPapers();
    setupPagination();
    updateResultsCount();
}

// Initialize the page
document.addEventListener('DOMContentLoaded', function() {
    createStars();
    loadData();
});