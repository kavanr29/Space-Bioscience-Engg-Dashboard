from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
from io import StringIO
from datetime import datetime
import requests
import pandas as pd
import re
import json

app = Flask(__name__)
CORS(app)

class SpaceBiologyData:
    def __init__(self):
        self.csv_url = 'https://raw.githubusercontent.com/jgalazka/SB_publications/main/SB_publication_PMC.csv'
        self.df = None
        self.papers = []
        self.topic_summaries = {}
        # discovered author-like columns in the CSV (populated after load)
        self.author_columns = []
        
    def load_data(self):
        """Load data from GitHub CSV"""
        try:
            print("Loading CSV from GitHub...")
            resp = requests.get(self.csv_url, timeout=15)
            resp.raise_for_status()
            csv_text = resp.text
            self.df = pd.read_csv(StringIO(csv_text))
            print(f"Loaded dataframe with {len(self.df)} rows and {len(self.df.columns)} columns")
            # detect columns likely containing author information
            self.detect_author_columns()
            print(f"Detected author-like columns: {self.author_columns}")
            # build paper objects
            self.process_papers()
            # topic summary generation may rely on papers; call if implemented
            try:
                self.generate_topic_summaries()
            except Exception:
                pass
            return True
        except Exception as e:
            print("Failed to load CSV:", e)
            return False
    
    def detect_author_columns(self):
        """Detect columns that likely contain author information"""
        if self.df is None:
            return []
        
        # Heuristic: look for columns with names containing 'author', 'contributor', or similar
        possible_author_columns = []
        for column in self.df.columns:
            cl = str(column).lower()
            if any(k in cl for k in ('author', 'creator', 'contributor', 'affiliat', 'au', 'byline')):
                possible_author_columns.append(column)
        # also inspect samples for list-like separators
        for column in self.df.columns:
            if column in possible_author_columns:
                continue
            try:
                sample = self.df[column].dropna().astype(str).iloc[0]
            except Exception:
                sample = ''
            if sample and (';' in sample or '|' in sample or '[' in sample and ']' in sample):
                possible_author_columns.append(column)
        
        # Keep only the first few unique columns that were detected as author-like
        self.author_columns = possible_author_columns[:5]
        return self.author_columns
    
    def process_papers(self):
        """Process raw CSV data into paper objects"""
        self.papers = []
        
        for idx, row in self.df.iterrows():
            try:
                title = (row.get('Title') or row.get('title') or row.get('ArticleTitle') or '').strip()
                if not title:
                    continue
                # extract authors using detected columns and heuristics
                authors = self.get_authors_from_row(row)
                journal = (row.get('Journal') or row.get('journal') or row.get('SourceTitle') or '').strip()
                publisher = (row.get('Publisher') or row.get('publisher') or '').strip()
                # publication date/year
                pub_date = row.get('PublicationDate') or row.get('Year') or row.get('PubDate') or ''
                year = self.extract_year(pub_date) if pub_date else ''
                abstract = row.get('Abstract') or row.get('abstract') or row.get('Summary') or ''
                url = row.get('URL') or row.get('Link') or row.get('PMCID') or ''
                paper = {
                    "id": int(idx) if pd.notna(idx) else len(self.papers) + 1,
                    "title": title,
                    "authors": authors,
                    "journal": journal or 'Unknown Journal',
                    "publisher": publisher or self.get_publisher(publisher, journal) if hasattr(self, 'get_publisher') else '',
                    "date": year or '',
                    "abstract": abstract if pd.notna(abstract) else '',
                    "detailed_summary": self.generate_detailed_summary(row, abstract) if hasattr(self, 'generate_detailed_summary') else '',
                    "tags": self.generate_tags(title, abstract) if hasattr(self, 'generate_tags') else [],
                    "url": url if pd.notna(url) else '',
                    "has_abstract": bool(abstract and str(abstract).strip()),
                    "primary_topic": self.identify_primary_topic(title, abstract) if hasattr(self, 'identify_primary_topic') else None
                }
                self.papers.append(paper)
            except Exception:
                continue
        
        print(f"Successfully processed {len(self.papers)} papers")
    
    def generate_topic_summaries(self):
        """Generate comprehensive summaries for each research topic"""
        self.topic_summaries = {
            'microgravity': {
                'name': 'Microgravity Effects',
                'summary': """Microgravity research represents one of the most fundamental areas of space biology, examining how biological systems function in the absence of Earth's gravity. This research investigates cellular processes, gene expression patterns, and physiological adaptations that occur when gravity is removed from the equation. Studies consistently show significant alterations in cell division cycles, protein synthesis rates, and metabolic pathway regulation under microgravity conditions. Plant systems demonstrate remarkable changes in root architecture, gravitropic responses, and cell wall development when grown in space. Mammalian cells exhibit profound modifications in cytoskeleton organization, signal transduction mechanisms, and gene regulation networks. The immune system undergoes substantial changes with reduced lymphocyte activation capacity and altered cytokine production profiles. Microgravity provides a unique laboratory for understanding fundamental biological processes by eliminating gravitational influences that have shaped evolution on Earth. This research is absolutely critical for developing effective countermeasures to maintain astronaut health during long-duration space missions. Applications extend beyond spaceflight to advancements in biomedical research, tissue engineering, and understanding disease mechanisms on Earth. Current research utilizes sophisticated platforms including the International Space Station, parabolic flight aircraft, and ground-based simulators like clinostats and random positioning machines.""",
                'key_findings': [
                    'Altered gene expression profiles across multiple biological systems and cell types',
                    'Significant changes in cell morphology, division patterns, and communication',
                    'Modified immune response characteristics with increased infection susceptibility',
                    'Altered bone density regulation and muscle mass maintenance mechanisms'
                ]
            },
            'radiation': {
                'name': 'Space Radiation Biology',
                'summary': """Space radiation biology investigates the complex effects of cosmic radiation on living organisms, representing a major challenge for human space exploration beyond Earth's protective magnetosphere. This field examines DNA damage mechanisms, cellular repair processes, and long-term health risks associated with exposure to galactic cosmic rays and solar particle events. Space radiation consists of high-energy protons, heavy ions, and secondary particles that create complex DNA lesions difficult for cellular repair systems to handle efficiently. Biological consequences include dramatically increased mutation rates, chromosomal aberrations, and elevated lifetime cancer risks for exposed astronauts. Research focuses intensely on developing advanced shielding materials, pharmacological countermeasures, and biological protection strategies. Radiation-sensitive tissues like the central nervous system, hematopoietic system, and gastrointestinal tract show particular vulnerability to space radiation effects. Studies employ particle accelerators to simulate space radiation conditions and investigate biological responses in controlled laboratory settings. Findings directly contribute to establishing radiation protection standards and developing safety protocols for future lunar and Mars missions. This research also drives innovations in cancer radiotherapy techniques and improves radiation safety protocols for medical and industrial applications on Earth. Understanding individual variations in radiation sensitivity is becoming increasingly important for personalized risk assessment and protection strategies.""",
                'key_findings': [
                    'Complex DNA damage patterns requiring specialized cellular repair mechanisms',
                    'Significantly increased oxidative stress levels and chronic inflammation markers',
                    'Tissue-specific vulnerability patterns with nervous system showing high sensitivity',
                    'Potential long-term cognitive function impacts from central nervous system exposure'
                ]
            },
            'plants': {
                'name': 'Space Plant Biology',
                'summary': """Space plant biology represents a critical research area focused on understanding how plants grow, develop, and reproduce in the unique environment of space, essential for developing sustainable life support systems for long-duration missions. This research investigates fundamental plant processes including photosynthesis efficiency, respiration rates, nutrient uptake mechanisms, and reproductive development under microgravity and space radiation conditions. Plants consistently demonstrate altered root system architecture, modified gravitropic responses, and significant changes in cell wall development when cultivated in space environments. Gene expression analysis reveals profound shifts in stress response pathways, metabolic regulation, and developmental programming compared to Earth-grown controls. Research directly addresses the challenges of developing robust bioregenerative life support systems that can provide food, oxygen, and psychological benefits for crew members. Studies examine seed germination success rates, plant growth characteristics, flowering patterns, and fruit production in various space conditions. This research contributes significantly to advancing space agriculture capabilities while providing fundamental insights into plant physiology and adaptation mechanisms. Applications extend to improving terrestrial agricultural practices and developing stress-resistant crop varieties. Current investigations focus on optimizing growth conditions, selecting space-adapted plant varieties, and understanding plant-microbe interactions in closed systems.""",
                'key_findings': [
                    'Dramatically altered root system architecture with modified branching patterns',
                    'Significant changes in gene expression related to stress responses and development',
                    'Modified secondary metabolite production affecting nutritional quality',
                    'Adapted photosynthetic efficiency and light utilization in space conditions'
                ]
            },
            'microbes': {
                'name': 'Space Microbiology',
                'summary': """Space microbiology examines how bacteria, fungi, viruses, and other microorganisms adapt and behave in spaceflight environments, with critical implications for astronaut health, spacecraft systems, and life support operations. This research investigates changes in microbial growth characteristics, metabolic activities, virulence factors, and antibiotic resistance patterns under microgravity conditions. Spaceflight consistently induces alterations in microbial gene expression profiles, leading to modified pathogenicity characteristics, enhanced stress resistance, and changed metabolic capabilities. Research addresses crucial challenges in microbial management within closed spacecraft environments and assesses infection risks for crew members during extended missions. Microbial communities play essential roles in advanced life support systems, contributing to waste processing, air revitalization, and potential food production. Studies examine biofilm formation tendencies on various spacecraft materials and equipment surfaces, informing contamination control strategies. Findings directly contribute to developing effective antimicrobial approaches, monitoring spacecraft microbiomes, and maintaining system integrity. Research also explores beneficial microbial applications in resource recycling, environmental control, and agricultural processes for space habitats. Space provides extraordinary conditions for studying microbial evolution, adaptation mechanisms, and ecosystem dynamics in controlled environments. Applications extend to improving infection control in healthcare settings, advancing industrial microbiology, and understanding microbial ecology.""",
                'key_findings': [
                    'Increased virulence characteristics observed in several bacterial pathogens',
                    'Significantly altered antibiotic resistance profiles and susceptibility patterns',
                    'Enhanced biofilm formation capabilities on various material surfaces',
                    'Modified metabolic pathway activation and energy production mechanisms'
                ]
            },
            'human': {
                'name': 'Human Space Physiology',
                'summary': """Human space physiology represents a comprehensive research domain investigating how the human body adapts to spaceflight environments, focusing on maintaining crew health and performance during extended missions. This research examines cardiovascular system deconditioning, skeletal muscle atrophy, bone density loss, and fluid distribution shifts that occur in microgravity conditions. Studies address neurovestibular system adaptation processes, including space motion sickness incidence, sensorimotor integration challenges, and spatial orientation mechanisms in weightlessness. The immune system demonstrates significant functional changes with altered leukocyte distribution patterns, reduced immune response capabilities, and modified inflammatory regulation. Sleep architecture, circadian rhythm regulation, and psychological adaptation represent critical research areas for ensuring crew well-being and mission success. Nutritional requirements, metabolic adaptations, and energy balance in space are extensively investigated to optimize crew health maintenance. Research drives the development of countermeasures including specialized exercise protocols, pharmacological interventions, nutritional supplements, and environmental modifications. Findings contribute profoundly to understanding human aging processes, chronic disease mechanisms, and disuse syndromes relevant to terrestrial medicine. Long-duration mission research increasingly focuses on integrated physiological adaptation patterns and comprehensive health maintenance strategies. Applications include advancements in rehabilitation medicine, understanding bed-rest related physiological changes, and developing remote health monitoring systems.""",
                'key_findings': [
                    'Approximately 1-2% monthly bone density loss in weight-bearing bones despite countermeasures',
                    'Cardiovascular deconditioning manifesting as reduced exercise capacity and orthostatic intolerance',
                    'Significant fluid shifts leading to facial edema, sinus congestion, and reduced leg volume',
                    'Neurovestibular adaptation requiring substantial post-flight recovery and rehabilitation periods'
                ]
            },
            'drosophila': {
                'name': 'Drosophila Space Research',
                'summary': """Drosophila melanogaster, the common fruit fly, serves as an exceptionally valuable model organism for space biology research, providing insights into genetic, developmental, and physiological responses to spaceflight conditions. Studies utilize fruit flies to investigate effects on reproduction cycles, developmental processes, aging mechanisms, and behavioral patterns in space environments. This model organism offers significant advantages including short generation times, well-characterized genetics, relatively simple maintenance requirements, and established research methodologies. Research examines DNA damage response mechanisms, oxidative stress management, cellular repair processes, and adaptive responses under space conditions. Findings contribute fundamentally to understanding biological processes affected by spaceflight with direct relevance to human health considerations. Drosophila research helps identify evolutionarily conserved biological responses across species, providing insights into universal space adaptation mechanisms. Studies support the development of countermeasures for radiation protection and microgravity effects applicable to human spaceflight. Research continues to provide crucial insights into space adaptation biology, evolutionary processes, and fundamental biological mechanisms. The model enables investigation of transgenerational effects and evolutionary adaptation potential in space environments. Applications extend to understanding human disease mechanisms, aging processes, and environmental stress responses on Earth.""",
                'key_findings': [
                    'Altered developmental timing and life cycle progression under space conditions',
                    'Significant changes in gene expression related to stress response pathways',
                    'Modified behavioral patterns, activity levels, and circadian rhythm regulation',
                    'Observable transgenerational effects on offspring development and characteristics'
                ]
            },
            'rodent': {
                'name': 'Rodent Space Research',
                'summary': """Rodent research provides absolutely essential insights into mammalian adaptation to spaceflight conditions, serving as a crucial bridge between cellular studies and human physiological responses. Studies using mice and rats investigate bone density changes, muscle atrophy patterns, immune system function alterations, and metabolic adaptations in space environments. Research examines neurological changes including brain structure modifications, cognitive function assessments, and behavioral adaptations under microgravity conditions. Rodent models significantly advance understanding of cardiovascular system adaptation, fluid balance regulation, and metabolic changes relevant to human spaceflight. Studies investigate tissue regeneration capabilities, wound healing processes, and stem cell behavior in microgravity, informing regenerative medicine approaches. Research contributes fundamentally to developing countermeasures for human spaceflight health risks and establishing safety standards for long-duration missions. Rodent studies effectively connect cellular and molecular findings to whole-organism physiological responses and integrated system adaptations. Findings have profound applications in understanding human aging processes, osteoporosis mechanisms, muscle wasting disorders, and metabolic diseases on Earth. Research protocols continuously improve to ensure rodent health, welfare, and scientific validity in space experimentation. Studies provide indispensable data for mission planning, risk assessment, and countermeasure development for future exploration missions.""",
                'key_findings': [
                    'Rapid skeletal muscle atrophy with significant strength and endurance reduction',
                    'Altered bone remodeling balance leading to progressive density loss',
                    'Substantial changes in immune cell populations, distribution, and functional capacity',
                    'Neurological adaptations affecting sensorimotor integration and coordination'
                ]
            },
            'cell_biology': {
                'name': 'Space Cell Biology',
                'summary': """Space cell biology investigates fundamental cellular processes under microgravity conditions, providing insights into basic biological mechanisms and their adaptation to space environments. This research examines changes in cell growth characteristics, differentiation pathways, gene expression patterns, and signal transduction mechanisms in weightlessness. Studies focus intensely on cytoskeleton organization, cell adhesion dynamics, extracellular matrix interactions, and mechanical sensing in the absence of gravity. Space provides extraordinary conditions for advancing tissue engineering approaches and developing sophisticated three-dimensional cell culture models. Research investigates stem cell behavior including proliferation rates, differentiation potential, and functional characteristics under spaceflight conditions. Studies contribute significantly to understanding cancer biology mechanisms, metastatic potential, and tumor development processes in microgravity. Immune cell function including activation mechanisms, cytokine production, and response characteristics receives extensive research attention. Findings drive innovations in regenerative medicine approaches, tissue engineering strategies, and biomedical technology development with terrestrial applications. Research supports the development of advanced life support systems, biomedical monitoring technologies, and therapeutic approaches for space missions. Cell biology studies provide fundamental understanding of space adaptation mechanisms at the most basic biological level.""",
                'key_findings': [
                    'Significant alterations in cytoskeleton organization and overall cell morphology',
                    'Comprehensive changes in gene expression profiles across diverse cell types',
                    'Modified cell-cell communication mechanisms and signaling pathway activation',
                    'Enhanced three-dimensional tissue formation capabilities and organization'
                ]
            },
            'immunology': {
                'name': 'Space Immunology',
                'summary': """Space immunology represents a critical research field investigating how the immune system responds to spaceflight conditions, with direct implications for crew health and mission success. This research examines changes in immune cell distribution patterns, functional capabilities, communication networks, and response characteristics under microgravity conditions. Studies address concerning increases in infection susceptibility, altered vaccine efficacy, and modified immune memory formation observed during and after space missions. Lymphocyte activation mechanisms, proliferation capacity, and cytokine production profiles demonstrate significant modifications in space environments. Natural killer cell activity characteristics, phagocytic function efficiency, and antigen presentation processes are substantially affected by spaceflight. Research investigates latent virus reactivation patterns, herpesvirus shedding incidence, and viral persistence mechanisms in astronaut populations. Studies examine the combined effects of microgravity, space radiation, psychological stress, and other spaceflight factors on integrated immune function. Findings contribute fundamentally to developing immune countermeasures, health monitoring protocols, and medical support systems for space missions. Research has important applications in understanding human immunosenescence processes, autoimmune disease mechanisms, and immune dysfunction on Earth. Studies provide essential support for crew health maintenance during long-duration exploration missions beyond Earth orbit.""",
                'key_findings': [
                    'Reduced T-cell activation capacity and proliferation potential in microgravity',
                    'Significantly altered cytokine production profiles and inflammatory regulation',
                    'Increased latent virus reactivation rates and viral shedding incidence',
                    'Substantial changes in leukocyte distribution patterns and trafficking behavior'
                ]
            },
            'neuroscience': {
                'name': 'Space Neuroscience',
                'summary': """Space neuroscience examines how the nervous system adapts to microgravity and spaceflight conditions, focusing on neural function, cognitive performance, and behavioral health during missions. This research investigates sensorimotor integration processes, vestibular function adaptation, spatial orientation mechanisms, and balance control in weightlessness. Studies address cognitive function characteristics including memory performance, attention capabilities, decision-making processes, and executive function in space environments. Neurovestibular adaptation involves complex recalibration of sensory integration, motor control mechanisms, and perceptual processes during spaceflight. Research examines changes in brain structure characteristics, neural connectivity patterns, and fluid distribution using advanced imaging techniques. Sleep quality assessment, circadian rhythm regulation, and their impacts on cognitive performance represent crucial research areas for mission success. Space motion sickness incidence, symptom patterns, and underlying neural mechanisms receive significant research attention. Findings contribute fundamentally to understanding neural plasticity mechanisms, adaptation processes, and learning capabilities in novel environments. Research has important applications in neurological rehabilitation approaches, disorder treatment strategies, and cognitive enhancement methods on Earth. Studies support the development of countermeasures for neurological adaptation challenges and performance maintenance during space missions.""",
                'key_findings': [
                    'Complex sensorimotor adaptation processes requiring post-flight recalibration periods',
                    'Observable changes in brain structure characteristics and fluid distribution patterns',
                    'Significant alterations in vestibular function and spatial orientation capabilities',
                    'Modified sleep architecture patterns and circadian rhythm regulation mechanisms'
                ]
            }
        }
    
    def generate_detailed_summary(self, row, abstract):
        """Generate a comprehensive summary for each paper"""
        title = str(row.get('Title', ''))
        primary_topic = self.identify_primary_topic(title, abstract)
        
        # Get the comprehensive topic summary
        if primary_topic in self.topic_summaries:
            topic_info = self.topic_summaries[primary_topic]
            base_summary = topic_info['summary']
            key_findings = topic_info.get('key_findings', [])
        else:
            base_summary = self.topic_summaries['microgravity']['summary']
            key_findings = self.topic_summaries['microgravity']['key_findings']
        
        # Create enhanced summary
        enhanced_summary = f"""RESEARCH OVERVIEW: {title}

This groundbreaking study represents a significant contribution to {primary_topic.replace('_', ' ').title()} research, addressing fundamental questions about biological adaptation to space environments.

COMPREHENSIVE TOPIC CONTEXT:
{base_summary}

SPECIFIC RESEARCH FOCUS:
This investigation specifically examines {self.get_research_focus(title, abstract)} through {self.infer_methodology(title, abstract)}. The research provides novel insights into {self.get_biological_system(title)} under space conditions.

KEY METHODOLOGICAL APPROACHES:
The study employs sophisticated research methodologies including {self.infer_detailed_methodology(title, abstract)} to address its research questions with scientific rigor and precision.

MAJOR CONTRIBUTIONS AND IMPLICATIONS:
Findings from this research significantly advance our understanding of {self.get_biological_system(title)} and have profound implications for {self.get_implications(title, primary_topic)}. The work contributes essential knowledge for {self.get_applications(primary_topic)}.

FUTURE RESEARCH DIRECTIONS:
This study opens exciting avenues for future investigation, particularly in areas such as {self.get_future_directions(primary_topic)}. Continued research in this domain will be crucial for {self.get_long_term_goals(primary_topic)}.

CONCLUSION:
This research represents a substantial advancement in space biology knowledge, providing critical insights that support both scientific understanding and practical applications for space exploration and terrestrial benefits."""
        
        return enhanced_summary
    
    def identify_primary_topic(self, title, abstract):
        """Identify the primary research topic"""
        content = f"{title} {abstract}".lower()
        
        topic_keywords = {
            'microgravity': ['microgravity', 'weightlessness', 'spaceflight', 'μg'],
            'radiation': ['radiation', 'cosmic', 'gamma', 'proton', 'ionizing'],
            'plants': ['plant', 'arabidopsis', 'root', 'photosynthesis', 'seedling'],
            'microbes': ['bacteria', 'microbial', 'yeast', 'fungal', 'virulence'],
            'human': ['human', 'astronaut', 'health', 'physiology', 'crew'],
            'drosophila': ['drosophila', 'fruit fly', 'melanogaster'],
            'rodent': ['mouse', 'mice', 'rat', 'rodent', 'murine'],
            'cell_biology': ['cell', 'cellular', 'in vitro', 'tissue', 'cytoskeleton'],
            'immunology': ['immune', 'immunology', 'lymphocyte', 'cytokine'],
            'neuroscience': ['neural', 'brain', 'behavior', 'cognitive', 'vestibular']
        }
        
        for topic, keywords in topic_keywords.items():
            if any(keyword in content for keyword in keywords):
                return topic
        
        return 'microgravity'
    
    def get_research_focus(self, title, abstract):
        """Extract research focus from title and abstract"""
        content = f"{title} {abstract}".lower()
        
        focus_map = {
            'effect': "the effects of space environment on biological systems and processes",
            'mechanism': "the underlying molecular and cellular mechanisms of space adaptation",
            'development': "developmental processes and growth patterns in space conditions",
            'response': "biological responses to spaceflight stressors and environmental challenges",
            'adaptation': "adaptive mechanisms and evolutionary responses to space environment",
            'change': "changes in biological function and system regulation in microgravity",
            'impact': "the impact of space conditions on physiological and cellular function"
        }
        
        for key, focus in focus_map.items():
            if key in content:
                return focus
        
        return "fundamental biological processes and system responses in space environments"
    
    def get_biological_system(self, title):
        """Identify the biological system studied"""
        title_lower = title.lower()
        
        systems = {
            'cell': 'cellular processes, organization, and communication mechanisms',
            'gene': 'gene expression patterns, regulation networks, and epigenetic modifications',
            'protein': 'protein synthesis, structure, function, and interaction networks',
            'dna': 'DNA integrity, damage response, and repair mechanism efficiency',
            'immune': 'immune system function, regulation, and response characteristics',
            'neural': 'neural development, function, and information processing mechanisms',
            'muscle': 'muscle physiology, maintenance mechanisms, and functional adaptation',
            'bone': 'bone density regulation, remodeling processes, and structural adaptation',
            'cardio': 'cardiovascular system function, regulation, and adaptation responses',
            'metabolic': 'metabolic pathways, energy production, and biochemical regulation'
        }
        
        for key, system in systems.items():
            if key in title_lower:
                return system
        
        return 'biological systems, processes, and adaptation mechanisms'
    
    def infer_methodology(self, title, abstract):
        """Infer research methodology"""
        content = f"{title} {abstract}".lower()
        
        methods = []
        if any(word in content for word in ['gene', 'expression', 'transcript']):
            methods.append('molecular biology techniques')
        if 'cell' in content:
            methods.append('cell culture approaches')
        if any(word in content for word in ['imaging', 'microscopy']):
            methods.append('advanced imaging methodologies')
        if any(word in content for word in ['sequence', 'genomic', 'transcriptomic']):
            methods.append('genomic and transcriptomic analysis')
        if 'protein' in content:
            methods.append('proteomic analysis techniques')
        if any(word in content for word in ['assay', 'measurement', 'analysis']):
            methods.append('biochemical assays and analytical methods')
        
        if not methods:
            methods = ['comprehensive space biology research protocols']
        
        return ', '.join(methods[:3])
    
    def infer_detailed_methodology(self, title, abstract):
        """Infer detailed research methodology"""
        content = f"{title} {abstract}".lower()
        
        methods = []
        if any(word in content for word in ['rna', 'transcript', 'expression']):
            methods.append('gene expression analysis')
        if any(word in content for word in ['protein', 'proteom']):
            methods.append('proteomic profiling')
        if any(word in content for word in ['cell', 'culture', 'in vitro']):
            methods.append('cell culture models')
        if any(word in content for word in ['imaging', 'microscopy', 'visualization']):
            methods.append('advanced imaging techniques')
        if any(word in content for word in ['assay', 'measurement', 'quantification']):
            methods.append('biochemical assays')
        if any(word in content for word in ['statistical', 'analysis', 'modeling']):
            methods.append('statistical analysis and computational modeling')
        
        return ', '.join(methods) if methods else 'sophisticated space biology research methodologies'
    
    def get_implications(self, title, topic):
        """Get research implications"""
        implications = {
            'microgravity': 'long-duration space mission planning, astronaut health maintenance, and fundamental biology understanding',
            'radiation': 'radiation protection strategies, cancer risk assessment, and safety protocol development',
            'plants': 'space agriculture development, closed ecological life support systems, and crop improvement',
            'microbes': 'spacecraft hygiene management, infection control protocols, and microbial application development',
            'human': 'countermeasure development, health monitoring systems, and performance optimization',
            'drosophila': 'fundamental biological mechanism understanding, model system validation, and evolutionary insights',
            'rodent': 'mammalian adaptation insights, therapeutic development, and translational research applications',
            'cell_biology': 'basic cellular mechanism elucidation, biomedical applications, and tissue engineering advances',
            'immunology': 'immune health maintenance, vaccine efficacy optimization, and disease prevention strategies',
            'neuroscience': 'neurological adaptation understanding, performance maintenance, and cognitive enhancement approaches'
        }
        
        return implications.get(topic, 'space exploration advancement, scientific knowledge expansion, and technological innovation')
    
    def get_applications(self, topic):
        """Get research applications"""
        applications = {
            'microgravity': 'advancing space exploration capabilities and improving terrestrial medical treatments',
            'radiation': 'enhancing radiation safety standards and advancing cancer therapy approaches',
            'plants': 'developing sustainable life support systems and improving agricultural productivity',
            'microbes': 'optimizing spacecraft operations and advancing industrial biotechnology',
            'human': 'ensuring crew health and performance during long-duration space missions',
            'drosophila': 'understanding fundamental biology and modeling human disease processes',
            'rodent': 'translating research findings to human health applications and drug development',
            'cell_biology': 'advancing regenerative medicine and understanding disease mechanisms',
            'immunology': 'improving vaccine development and understanding immune-related disorders',
            'neuroscience': 'enhancing neurological rehabilitation and understanding brain function'
        }
        
        return applications.get(topic, 'scientific advancement and practical implementation across multiple domains')
    
    def get_future_directions(self, topic):
        """Suggest future research directions"""
        directions = {
            'microgravity': 'long-term adaptation studies, integrated physiological monitoring, and countermeasure optimization',
            'radiation': 'combined stressor effects investigation, personalized protection approaches, and risk modeling refinement',
            'plants': 'multi-generational studies, optimized growth system development, and genetic adaptation analysis',
            'microbes': 'microbiome dynamics characterization, beneficial microbe applications, and evolutionary trajectory mapping',
            'human': 'individual variation studies, precision medicine approaches, and integrated health management systems',
            'drosophila': 'transgenerational effects analysis, evolutionary adaptation research, and genetic basis of space adaptation',
            'rodent': 'tissue-specific response characterization, regenerative medicine applications, and long-term health consequence assessment',
            'cell_biology': '3D tissue model development, organoid studies in space, and mechanobiology investigation',
            'immunology': 'immune resilience enhancement strategies, biomarker discovery, and personalized countermeasure development',
            'neuroscience': 'neural plasticity mechanism elucidation, cognitive enhancement strategies, and integrated brain-body adaptation studies'
        }
        
        return directions.get(topic, 'advanced technology implementation, interdisciplinary collaboration, and comprehensive system understanding')
    
    def get_long_term_goals(self, topic):
        """Get long-term research goals"""
        goals = {
            'microgravity': 'enabling safe and sustainable human presence in space and advancing fundamental biological knowledge',
            'radiation': 'ensuring crew safety during deep space exploration and improving radiation medicine on Earth',
            'plants': 'establishing self-sustaining life support systems and enhancing global food security',
            'microbes': 'harnessing microbial capabilities for space habitation and advancing biotechnology applications',
            'human': 'maintaining human health and performance during interplanetary travel and extended space residence',
            'drosophila': 'understanding evolutionary adaptation to space environments and modeling complex biological processes',
            'rodent': 'bridging basic research to human applications and developing effective countermeasures for space health risks',
            'cell_biology': 'revealing fundamental biological principles and advancing biomedical technologies for space and Earth',
            'immunology': 'ensuring immune health during space missions and understanding immune system evolution and function',
            'neuroscience': 'optimizing cognitive performance in space and understanding brain adaptation to novel environments'
        }
        
        return goals.get(topic, 'advancing human space exploration capabilities and expanding scientific understanding of life in the universe')
    
    def extract_year(self, publication_date):
        """Extract year from publication date"""
        if pd.isna(publication_date):
            return 'Unknown'
        
        date_str = str(publication_date)
        year_match = re.search(r'\d{4}', date_str)
        return year_match.group(0) if year_match else 'Unknown'
    
    def format_authors(self, authors):
        """Normalize/clean author strings"""
        if authors is None:
            return 'Unknown Authors'
        s = str(authors).strip()
        if not s or s.lower() in ('nan', 'none', 'unknown'):
            return 'Unknown Authors'
        # remove brackets, urls, dois and extra whitespace
        s = re.sub(r'\[.*?\]', '', s)
        s = re.sub(r'https?://\S+', '', s)
        s = re.sub(r'doi:\s*\S+', '', s, flags=re.I)
        s = re.sub(r'\s+', ' ', s).strip(' ,;')
        return s if s else 'Unknown Authors'
    
    def parse_authors_string(self, val):
        """Parse author strings in common formats into a cleaned string"""
        if val is None:
            return None
        s = str(val).strip()
        if not s or s.lower() in ('nan', 'none', 'unknown'):
            return None
        s = re.sub(r'\[.*?\]', '', s)
        s = re.sub(r'\s+', ' ', s).strip(' ,;')
        # common separators
        if s.startswith('[') and s.endswith(']'):
            try:
                arr = json.loads(s.replace("'", '"'))
                if isinstance(arr, list):
                    return self.format_authors(', '.join([str(x).strip() for x in arr if str(x).strip()]))
            except Exception:
                pass
        if ';' in s or '|' in s:
            parts = re.split(r'[;|]', s)
            parts = [p.strip(' .,' ) for p in parts if p.strip()]
            return self.format_authors(', '.join(parts))
        # try to extract Last, F. patterns
        matches = re.findall(r"[A-Za-z\-\']+,\s*[A-Za-z\.\-]+", s)
        if matches:
            return self.format_authors(', '.join(matches))
        return self.format_authors(s)
    
    def get_authors_from_row(self, row):
        """Robustly extract author names from detected columns or common fallbacks"""
        # 1) try detected columns first
        for col in self.author_columns:
            try:
                val = row.get(col)
            except Exception:
                val = None
            parsed = self.parse_authors_string(val)
            if parsed:
                return parsed
        # 2) common fallback headers
        for key in ('Authors','Author','AuthorList','AuthorsList','Author(s)','Contributors','Creator','AU','AU_LIST','BY'):
            val = row.get(key)
            parsed = self.parse_authors_string(val)
            if parsed:
                return parsed
        # 3) try separate name fields
        first = row.get('FirstName') or row.get('GivenName') or row.get('forenames')
        last = row.get('LastName') or row.get('FamilyName') or row.get('surname')
        if (pd.notna(first) and str(first).strip()) or (pd.notna(last) and str(last).strip()):
            names = ' '.join(filter(None, [str(first).strip() if pd.notna(first) else '', str(last).strip() if pd.notna(last) else ''])).strip()
            if names:
                return self.format_authors(names)
        # 4) heuristic scan of other columns
        name_pattern = re.compile(r"[A-Za-z\-\']+,\s*[A-Za-z\.\-]+")
        for _, cell in row.items():
            if pd.isna(cell):
                continue
            cell_str = str(cell)
            matches = name_pattern.findall(cell_str)
            if matches:
                return self.format_authors(', '.join(matches))
        return 'Unknown Authors'
    
    def format_abstract(self, abstract, title):
        """Format abstract text"""
        if pd.isna(abstract):
            return 'No abstract available for this publication.'
        
        abstract_str = str(abstract).strip()
        if not abstract_str:
            return 'No abstract available for this publication.'
        
        cleaned = re.sub(r'\s+', ' ', abstract_str)
        if not cleaned.endswith(('.', '!', '?')):
            cleaned += '.'
            
        return cleaned
    
    def format_field(self, field, default):
        """Format generic field"""
        if pd.isna(field):
            return default
        
        field_str = str(field).strip()
        return field_str if field_str else default
    
    def generate_tags(self, title, abstract):
        """Generate tags based on paper content"""
        tags = []
        title_text = (str(title) if pd.notna(title) else '').lower()
        abstract_text = (str(abstract) if pd.notna(abstract) else '').lower()
        content = f"{title_text} {abstract_text}"
        
        space_biology_terms = {
            'microgravity': 'Microgravity',
            'spaceflight': 'Spaceflight',
            'radiation': 'Radiation',
            'plant': 'Plant Biology',
            'arabidopsis': 'Arabidopsis',
            'drosophila': 'Drosophila',
            'mouse': 'Mouse Models',
            'human': 'Human Physiology',
            'bacteria': 'Bacteria',
            'immune': 'Immune System',
            'neural': 'Neural',
            'cell': 'Cell Biology',
            'gene': 'Gene Expression',
            'protein': 'Protein',
            'dna': 'DNA'
        }
        
        for term, tag in space_biology_terms.items():
            if term in content:
                tags.append(tag)
        
        if not tags:
            tags = ['Space Biology']
        
        return tags[:8]
    
    def create_paper_url(self, row):
        """Create URL to access the full paper (robust across common CSV column names)"""
        # Try common DOI fields first
        for key in ('DOI', 'doi', 'Doi'):
            doi_val = row.get(key)
            if pd.notna(doi_val):
                doi_str = str(doi_val).strip()
                doi_str = re.sub(r'^(doi:\s*|https?://(dx\.)?doi\.org/)', '', doi_str, flags=re.I)
                if doi_str:
                    return f"https://doi.org/{doi_str}"

        # Try PMC ID variants (allow PMC12345 or just numbers)
        for key in ('PMCID', 'pmcid', 'pmcId', 'pmc_id'):
            pmc_val = row.get(key)
            if pd.notna(pmc_val):
                pmc_str = str(pmc_val).strip()
                m = re.search(r'(PMC\d+)', pmc_str, flags=re.I)
                if m:
                    return f"https://www.ncbi.nlm.nih.gov/pmc/articles/{m.group(1).upper()}"
                digits = re.search(r'(\d+)', pmc_str)
                if digits:
                    return f"https://www.ncbi.nlm.nih.gov/pmc/articles/PMC{digits.group(1)}"

        # Try various URL/link fields
        for key in ('URL', 'Url', 'url', 'Link', 'link', 'ArticleURL', 'article_url'):
            u = row.get(key)
            if pd.notna(u):
                u_str = str(u).strip()
                if not u_str:
                    continue
                if not re.match(r'https?://', u_str, flags=re.I):
                    u_str = 'https://' + u_str
                return u_str

        return ''
    
    def get_publisher(self, publisher, journal):
        """Get or infer publisher information"""
        if pd.notna(publisher):
            publisher_str = str(publisher).strip()
            if publisher_str:
                return publisher_str
        
        journal_lower = journal.lower()
        if 'nature' in journal_lower:
            return 'Springer Nature'
        elif 'science' in journal_lower:
            return 'American Association for the Advancement of Science'
        elif 'cell' in journal_lower:
            return 'Cell Press'
        elif 'plos' in journal_lower:
            return 'Public Library of Science'
        else:
            return 'Various Publishers'
    
    def generate_simple_graph(self, max_topics=10, max_papers_per_topic=8):
        """Build a small, easy-to-render knowledge graph linking topics -> papers."""
        if not self.papers:
            return {"nodes": [], "edges": []}

        # Use topic_summaries keys if available, else derive from papers
        topics = list(self.topic_summaries.keys()) if self.topic_summaries else []
        if not topics:
            topics = sorted({p.get('primary_topic') or 'microgravity' for p in self.papers})

        # limit size
        topics = topics[:max_topics]

        nodes = []
        edges = []
        node_ids = set()

        # add topic nodes (include short summary if available)
        for t in topics:
            nid = f"topic::{t}"
            node_ids.add(nid)
            summary = self.topic_summaries.get(t, {}).get('name') if self.topic_summaries else None
            nodes.append({
                "id": nid,
                "type": "topic",
                "label": (self.topic_summaries.get(t, {}).get('name') if isinstance(self.topic_summaries.get(t, {}), dict) else str(t)).title(),
                "summary": (self.topic_summaries.get(t, {}).get('summary')[:280] + '...') if self.topic_summaries and self.topic_summaries.get(t, {}).get('summary') else ''
            })

        # for each topic, sample a few papers and link them
        for t in topics:
            related = [p for p in self.papers if (p.get('primary_topic') or '') == t]
            if not related:
                # fallback: any paper mentioning topic string
                related = [p for p in self.papers if t in (p.get('title','').lower() + ' ' + p.get('abstract','').lower())]
            for p in related[:max_papers_per_topic]:
                pid = f"paper::{p.get('id')}"
                if pid in node_ids:
                    continue
                node_ids.add(pid)
                nodes.append({
                    "id": pid,
                    "type": "paper",
                    "label": (p.get('title')[:120] + '...') if len(p.get('title','')) > 120 else p.get('title'),
                    "meta": {
                        "authors": p.get('authors'),
                        "year": p.get('date'),
                        "journal": p.get('journal')
                    }
                })
                edges.append({"source": pid, "target": f"topic::{t}", "relation": "about"})
        
        # add simple journal nodes for top journals (small set)
        journal_counts = {}
        for p in self.papers:
            j = p.get('journal') or 'Unknown'
            journal_counts[j] = journal_counts.get(j, 0) + 1
        top_journals = sorted(journal_counts.items(), key=lambda x: -x[1])[:8]
        for j, cnt in top_journals:
            jid = f"journal::{j}"
            if jid in node_ids:
                continue
            node_ids.add(jid)
            nodes.append({"id": jid, "type": "journal", "label": j, "count": cnt})
            # connect a representative paper to the journal
            rep = next((p for p in self.papers if p.get('journal') == j), None)
            if rep:
                edges.append({"source": f"paper::{rep.get('id')}", "target": jid, "relation": "published_in"})

        return {"nodes": nodes, "edges": edges}

# Initialize data handler
data_handler = SpaceBiologyData()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/papers')
def get_papers():
    """Get all papers with abstracts and summaries"""
    if not data_handler.papers:
        success = data_handler.load_data()
        if not success:
            return jsonify(get_sample_data())
    
    return jsonify(data_handler.papers)

@app.route('/api/papers/<int:paper_id>')
def get_paper(paper_id):
    """Get specific paper details"""
    if not data_handler.papers:
        data_handler.load_data()
    
    paper = next((p for p in data_handler.papers if p['id'] == paper_id), None)
    
    if paper:
        return jsonify(paper)
    else:
        return jsonify({'error': 'Paper not found'}), 404

@app.route('/api/topics')
def get_topics():
    """Get all research topics with their summaries"""
    if not data_handler.topic_summaries:
        data_handler.generate_topic_summaries()
    
    return jsonify(data_handler.topic_summaries)


@app.route('/api/graph')
def get_graph():
    """Return a lightweight knowledge graph (nodes/edges) for visualization.

    Nodes include topic nodes, journal nodes and a sample of paper nodes.
    Edges connect paper -> topic and paper -> journal.
    """
    if not data_handler.papers:
        data_handler.load_data()

    papers = data_handler.papers

    # Limit papers to avoid huge graphs in-browser
    max_papers = 250
    sample_papers = papers[:max_papers]

    nodes = []
    edges = []
    node_ids = set()

    # Add topic nodes
    topics = set(p.get('primary_topic') or 'microgravity' for p in sample_papers)
    for t in topics:
        nid = f"topic::{t}"
        node_ids.add(nid)
        nodes.append({"id": nid, "label": t.replace('_', ' ').title(), "group": "topic", "size": 30})

    # Add journal nodes (top ones only)
    journal_counts = {}
    for p in sample_papers:
        j = p.get('journal') or 'Unknown'
        journal_counts[j] = journal_counts.get(j, 0) + 1

    top_journals = sorted(journal_counts.items(), key=lambda x: -x[1])[:40]
    for j, _ in top_journals:
        nid = f"journal::{j}"
        node_ids.add(nid)
        nodes.append({"id": nid, "label": j, "group": "journal", "size": 22})

    # Add paper nodes and edges to topic/journal
    for p in sample_papers:
        pid = f"paper::{p.get('id')}"
        label = p.get('title')
        if not label:
            label = f"Paper {p.get('id')}"
        nodes.append({"id": pid, "label": label if len(label) <= 60 else label[:57] + '...', "group": "paper", "size": 10})

        topic = p.get('primary_topic') or 'microgravity'
        tnode = f"topic::{topic}"
        if tnode in node_ids:
            edges.append({"from": pid, "to": tnode})

        journal = p.get('journal') or None
        if journal:
            jnode = f"journal::{journal}"
            # If journal node not in nodes (might be filtered), add it
            if jnode not in node_ids and journal:
                node_ids.add(jnode)
                nodes.append({"id": jnode, "label": journal, "group": "journal", "size": 18})
            edges.append({"from": pid, "to": jnode})

    return jsonify({"nodes": nodes, "edges": edges})

@app.route('/api/statistics')
def get_statistics():
    """Get application statistics"""
    if not data_handler.papers:
        data_handler.load_data()
    
    papers = data_handler.papers
    
    total_papers = len(papers)
    papers_with_abstracts = len([p for p in papers if p['has_abstract']])
    
    journal_counts = {}
    for paper in papers:
        journal = paper['journal']
        if journal != 'Unknown Journal':
            journal_counts[journal] = journal_counts.get(journal, 0) + 1
    
    top_journal = 'Various'
    max_count = 0
    for journal, count in journal_counts.items():
        if count > max_count:
            max_count = count
            top_journal = journal
    
    current_year = datetime.now().year
    recent_papers = len([p for p in papers if p['date'].isdigit() and int(p['date']) >= current_year - 2])
    
    return jsonify({
        'total_papers': total_papers,
        'papers_with_abstracts': papers_with_abstracts,
        'top_journal': top_journal,
        'recent_papers': recent_papers
    })

@app.route('/api/search')
def search_papers():
    """Search papers by query"""
    query = request.args.get('q', '').lower()
    
    if not data_handler.papers:
        data_handler.load_data()
    
    if not query:
        return jsonify(data_handler.papers[:50])
    
    filtered_papers = []
    for paper in data_handler.papers:
        if (query in paper['title'].lower() or
            query in paper['authors'].lower() or
            query in paper['abstract'].lower() or
            query in paper['journal'].lower() or
            any(query in tag.lower() for tag in paper['tags'])):
            filtered_papers.append(paper)
    
    return jsonify(filtered_papers)

@app.route('/api/knowledge_graph')
def knowledge_graph():
    """Simple, lightweight knowledge graph suitable for quick visualizations."""
    if not data_handler.papers:
        data_handler.load_data()
    graph = data_handler.generate_simple_graph(max_topics=8, max_papers_per_topic=6)
    return jsonify(graph)

def get_sample_data():
    """Fallback sample data"""
    return [
        {
            "id": 1,
            "title": "Effects of Microgravity on Arabidopsis thaliana Root Growth and Development",
            "authors": "Smith, J., Johnson, A., Williams, R., Brown, K., Davis, M., Wilson, E.",
            "journal": "Nature Communications",
            "publisher": "Springer Nature",
            "date": "2023",
            "abstract": "This comprehensive study investigates the impact of simulated microgravity on the root system architecture of Arabidopsis thaliana, revealing significant alterations in root growth patterns and gene expression.",
            "detailed_summary": "Detailed summary about microgravity effects on plant systems...",
            "tags": ["Microgravity", "Plant Biology", "Arabidopsis", "Gene Expression"],
            "url": "https://www.nature.com/articles/s41467-023-39944-x",
            "has_abstract": True,
            "primary_topic": "plants"
        }
    ]

if __name__ == '__main__':
    print("Starting Space Biology Knowledge Engine...")
    data_handler.load_data()
    app.run(debug=True, port=5000)